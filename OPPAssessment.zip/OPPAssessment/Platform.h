#pragma once

class Platform {
public:
	float startX;
	float startY;

	float endX;
	float endY;

	void draw();
};