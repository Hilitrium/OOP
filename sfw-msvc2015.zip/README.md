# sfw-AIE-Framework

Contact me, Esmeralda Salamone, at esmes@aie.edu.au for any complaints/feature requests.

INTENDED FOR EDUCATIONAL USE.

Simple wrapper for GLFW/GLM/STB and OpenGL Loader (I will totes cut this for GLEW because it has no acronym).

Preliminary readme. Download release for example project. Instructions for use in nsfwdraw.h.

For users, sfw::initContext may only be called once per application execution and must be called before anything else (otherwise YMMV).

No depth testing, but transparency is supported.

# License

Copyright (c) 2016-2017 Academy of Interactive Entertainment All rights reserved.